
ver01:
Set sensor sampling rate to 'very_low_speed'
Set sensor ref voltage to 3.3V (internal)
Read_Sensor now calculates a recursive mean, if the reading >0, until the data is written. This results in a mean value between data writes and transmits.
Data is written at the same time as it's transmitted by radio.
LED flashes on before write/ send, off on completion. Previsoulsy this went on with write, off with next write.
